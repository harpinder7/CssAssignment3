<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Get the form data
  $name = $_POST["name"];
  $email = $_POST["email"];
  

  // Do something with the form data (e.g. send an email)
  echo('Your query has been and will be responded very soon')

  // Redirect the user to a thank-you page
  header("Location: thank-you.html");
  exit;
}
?>
